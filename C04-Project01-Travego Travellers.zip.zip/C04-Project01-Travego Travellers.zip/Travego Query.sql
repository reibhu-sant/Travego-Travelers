-- 1a
CREATE SCHEMA Travego;

USE Travego;

-- 1b
CREATE TABLE Passenger (
    Passenger_id INT NOT NULL,
    Passenger_name VARCHAR(50) NOT NULL,
    Category VARCHAR(50),
    Gender CHAR(5),
    Boarding_City VARCHAR(50) NOT NULL,
    Destination_City VARCHAR(50) NOT NULL,
    Distance INT NOT NULL,
    BUS_TYPE VARCHAR(50) NOT NULL,
    PRIMARY KEY (Passenger_id)
);

CREATE TABLE Price (
    id INT NOT NULL,
    Bus_type VARCHAR(50) NOT NULL,
    Distance INT,
    Price INT,
    PRIMARY KEY (id)
);


-- 1c
INSERT INTO passenger VALUES('1','Sejal','AC','F','Bengaluru','Chennai','350','Sleeper');
INSERT INTO passenger VALUES('2','Anmol','Non-AC','M','Mumbai','Hyderabad','700','Sitting');
INSERT INTO passenger VALUES('3','Pallavi','AC','F','Panaji','Bengaluru','600','Sleeper');
INSERT INTO passenger VALUES('4','Khusboo','AC','F','Chennai','Mumbai','1500','Sleeper');
INSERT INTO passenger VALUES('5','Udit','Non-AC','M','Trivandrum','Panaji','1000','Sleeper');
INSERT INTO passenger VALUES('6','Ankur','AC','M','Nagpur','Hyderabad','500','Sitting');
INSERT INTO passenger VALUES('7','Hemant','Non-AC','M','Panaji','Mumbai','700','Sleeper');
INSERT INTO passenger VALUES('8','Manish','Non-AC','M','Hyderabad','Bengaluru','500','Sitting');
INSERT INTO passenger VALUES('9','Piyush','AC','M','Pune','Nagpur','700','Sitting');

INSERT INTO Price VALUES('1','Sleeper','350','770');
INSERT INTO Price VALUES('2','Sleeper','500','1100');
INSERT INTO Price VALUES('3','Sleeper','600','1320');
INSERT INTO Price VALUES('4','Sleeper','700','1540');
INSERT INTO Price VALUES('5','Sleeper','1000','2200');
INSERT INTO Price VALUES('6','Sleeper','1200','2640');
INSERT INTO Price VALUES('7','Sleeper','1500','2700');
INSERT INTO Price VALUES('8','Sitting','500','620');
INSERT INTO Price VALUES('9','Sitting','600','744');
INSERT INTO Price VALUES('10','Sitting','700','868');
INSERT INTO Price VALUES('11','Sitting','1000','1240');
INSERT INTO Price VALUES('12','Sitting','1200','1488');
INSERT INTO Price VALUES('13','Sitting','1500','1860');

-- 2a
SELECT gender, COUNT(gender) FROM passenger WHERE distance >=600 GROUP BY gender;
-- 2b
SELECT id, MIN(price) FROM Price; 
-- 2c
SELECT * FROM passenger WHERE Passenger_name LIKE 'S%'; 
-- 2d
SELECT Passenger_name, Boarding_City, Destination_City, PS.BUS_TYPE, Price FROM passenger AS PS, price AS PR WHERE PS.BUS_TYPE=PR.Bus_type AND PS.Distance=PR.Distance; 
-- 2e
SELECT Passenger_name, PR.price  FROM passenger AS PS, price AS PR WHERE PS.Distance>=1000 AND PS.BUS_TYPE LIKE 'Sitting';
-- 2f
SELECT Passenger_name, PR.BUS_TYPE, PR.price  FROM passenger AS PS, price AS PR WHERE PS.Passenger_name LIKE 'Pallavi' AND PS.Distance=PR.Distance ;
-- 2G
SELECT DISTINCT(Distance) from passenger;
-- 2f
SELECT Passenger_name, Distance*100/(SELECT SUM(Distance) FROM passenger) AS Percentage FROM passenger;
